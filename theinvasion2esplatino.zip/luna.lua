-- Traducción hecha por porog
-- Translation by porog
function onMessageBox(eventObj, msgStr)
	if msgStr == "Oh no, where did the Princess go?" then
		eventObj.cancelled = true
		Text.showMessageBox("Hay no, donde esta la princesa?")
	elseif string.find(msgStr, "house calls") then
		eventObj.cancelled = true
		Text.showMessageBox("Una princesa no deberia hacer visitas domicilarias a un fontanero!")
	elseif string.find(msgStr, "but I had to") then
		eventObj.cancelled = true
		Text.showMessageBox("No me dejaban entrar, pero tenia que hablar contigo")
	elseif string.find(msgStr, "Something bad is") then
		eventObj.cancelled = true
		Text.showMessageBox("No me mires haci... algo terrible esta susediendo!")
	elseif string.find(msgStr, "Bowser has joined forces") then
		eventObj.cancelled = true
		Text.showMessageBox("Bowser unio fuerzas con villanos de otras realidades y esta invadiendo el Reino de los Hongos.")
	elseif string.find(msgStr, "Please go foil") then
		eventObj.cancelled = true
		Text.showMessageBox("porfavor anda a arruinar sus planes como siempre.")
	elseif string.find(msgStr, "Please be careful") then
		eventObj.cancelled = true
		Text.showMessageBox("Por favor tene cuidado.. el camino por delante es muy peligroso!")
	elseif string.find(msgStr, "change your character at") then
		eventObj.cancelled = true
		Text.showMessageBox("Sabias que podes cambiar de personaje en la pantalla del mapa de mundo?")
	elseif string.find(msgStr, "All you have to do") then
		eventObj.cancelled = true
		Text.showMessageBox("Solo tenes que pausar el juego y pulsar derecha o izquierda.")
	elseif string.find(msgStr, "Aren't you that") then
		eventObj.cancelled = true
		Text.showMessageBox("Vos no sos el fontanero del que habla todo el mundo? Toma, podes tener lo que esta en este cofre.")
	elseif string.find(msgStr, "I hope that was") then
		eventObj.cancelled = true
		Text.showMessageBox("Espero que te haiga servido de ayuda.")
	elseif string.find(msgStr, "in that pipe above us") then
		eventObj.cancelled = true
		Text.showMessageBox("Me pregunto que ahi en ese tubo arriba de nosotros Talvez pudiera llegar si tuviera un zapato gigante o algo que me ayude a subir.")
	elseif string.find(msgStr, "believe that pipe") then
		eventObj.cancelled = true
		Text.showMessageBox("No puedo creer que ese tubo nos suba tan alto en el cielo.")
	elseif string.find(msgStr, "means there is a secret exit") then
		eventObj.cancelled = true
		Text.showMessageBox("Este nivel aparece rojo en el mapa de mundo. Eso significa que ahi una salida secreta en alguna parte. Podes encontrarla?")
	elseif string.find(msgStr, "been ordered to get rid") then
		eventObj.cancelled = true
		Text.showMessageBox("Me ordenaron que destruyera todos los bloques violetas. Voy a estar aca toda la noche")
	elseif string.find(msgStr, "open this door for you.") then
		eventObj.cancelled = true
		Text.showMessageBox("Destruistes todos los bloques violetas! Como recompensa voy a abrir esta puerta.")
	elseif string.find(msgStr, "have anything you find") then
		eventObj.cancelled = true
		Text.showMessageBox("Podes tener cualquier cosa que encuentres ahi.")
	elseif string.find(msgStr, "You can throw a shell in many") then
		eventObj.cancelled = true
		Text.showMessageBox("Podes tirar un caparazon de muchas maneras diferentes dependiendo de que direccion tengas pulsada en el control al soltar el boton de correr.")
	elseif string.find(msgStr, "while standing on them.") then
		eventObj.cancelled = true
		Text.showMessageBox("Mantene pulsado ABAJO y presiona el boton de CORRER para levantar enemigos mientras estas encima de ellos.")
	elseif string.find(msgStr, "If we are underground") then
		eventObj.cancelled = true
		Text.showMessageBox("Si estamos bajo tierra, porque se ve el cielo?")
	elseif string.find(msgStr, "on the other side of this wall?") then
		eventObj.cancelled = true
		Text.showMessageBox("Me pregunto que ahi del otro lado de esta pared? Podria romperla si tuviera un martillo.")
	elseif string.find(msgStr, "take this through the pipe.") then
		eventObj.cancelled = true
		Text.showMessageBox("No podes llevar esto atraves del tubo. Activalo ahora, y anda ver si algo pasa del otro lado.")
	elseif string.find(msgStr, "My rocket was hit by one of those bombs.") then
		eventObj.cancelled = true
		Text.showMessageBox("Mi coete fue golpeado por una de esas bombas. Ahora estoy atrapado aca.")
	elseif string.find(msgStr, "Help, I can't swim!") then
		eventObj.cancelled = true
		Text.showMessageBox("Ayuda, no se nadar!")
	elseif string.find(msgStr, "mushrooms coming from") then
		eventObj.cancelled = true
		Text.showMessageBox("De donde salen esos hongos?")
	elseif string.find(msgStr, "You look like an honest") then
		eventObj.cancelled = true
		Text.showMessageBox("Vos pareces una persona honesta. Voy a dejarte pasar, pero tene cuidado con mis huevos.")
	elseif string.find(msgStr, "What's wrong with you, why") then
		eventObj.cancelled = true
		Text.showMessageBox("Che que te pasa? porque destruistes mis huevos? Sali de aca, invecil!")
	elseif string.find(msgStr, "The glowing thing above us") then
		eventObj.cancelled = true
		Text.showMessageBox("La cosa radiante de arriba es el Billy Gun. Cuando la agarres, sujetate fuerte!")
	elseif string.find(msgStr, "I've been waiting in line") then
		eventObj.cancelled = true
		Text.showMessageBox("Estuve esperando en la fila por siempre!")
	elseif string.find(msgStr, "This place looks so fun") then
		eventObj.cancelled = true
		Text.showMessageBox("Este lugar parece super divertido. Estoy con muchas ganas de entrar!")
	elseif string.find(msgStr, "Hey you! No cutting") then
		eventObj.cancelled = true
		Text.showMessageBox("Ey! No te coles.")
	elseif string.find(msgStr, "Let me OUT!") then
		eventObj.cancelled = true
		Text.showMessageBox("Sacame de aca! SACAME DE ACA!")
	elseif string.find(msgStr, "There are monsters everywhere.") then
		eventObj.cancelled = true
		Text.showMessageBox("El nos mintio. Aca esta lleno de mosntruos.")
	elseif string.find(msgStr, "I bet something good will happen") then
		eventObj.cancelled = true
		Text.showMessageBox("Apuesto a que algo bueno pasa si recoges todas las monedas azules!")
	elseif string.find(msgStr, "Shouldn't this level be in") then
		eventObj.cancelled = true
		Text.showMessageBox("Este nivel no debe estar en el mundo de hielo? Da igual...")
	elseif string.find(msgStr, "I AM ERROR.") then
		eventObj.cancelled = true
		Text.showMessageBox("YO SOY ERROR.")
	elseif string.find(msgStr, "moles that live here used to be") then
		eventObj.cancelled = true
		Text.showMessageBox("Hasta hace poco, los topos que viven aca eran amigables. Pero ahora algo esta pasando que hace que se pongan muy agresivos. Tene cuidado!")
	elseif string.find(msgStr, "Why is it called Pwnhammer") then
		eventObj.cancelled = true
		Text.showMessageBox("Y porque se llama Pwnhammer?")
	elseif string.find(msgStr, "blue plants look suspicious") then
		eventObj.cancelled = true
		Text.showMessageBox("Esas plantas azules parecen sospechosas. Si agarras una no la sueltes!")
	elseif msgStr == "Help!" then
		eventObj.cancelled = true
		Text.showMessageBox("Auxilio!")
	elseif string.find(msgStr, "Bowser's airships are invading!") then
		eventObj.cancelled = true
		Text.showMessageBox("Los aeronaves de Bowser nos imbaden!")
	elseif string.find(msgStr, "If you hold down and press run") then
		eventObj.cancelled = true
		Text.showMessageBox("Si mantenes pulsado abajo y pulsas correr en la parte del nave que es azul, conseguis un objeto especial!")
	elseif string.find(msgStr, "Hurry up and get on.") then
		eventObj.cancelled = true
		Text.showMessageBox("Date prisa y subi al nave. Estan apunto de salir sin vos!")
	elseif string.find(msgStr, "allow their wearers to walk") then
		eventObj.cancelled = true
		Text.showMessageBox("Estos son los zapatos de Podoboo. Permiten al usuario caminar sobre la lava!")
	elseif string.find(msgStr, "have been lost in here for days.") then
		eventObj.cancelled = true
		Text.showMessageBox("Tenes algo para comer? Me perdi aca por dias")
	elseif string.find(msgStr, "The enemy ahead can") then
		eventObj.cancelled = true
		Text.showMessageBox("El enemigo por delante es bastante fuerte. Usa las plantas y derrotalo tan rapido como puedas")
	elseif string.find(msgStr, "You better move quick") then
		eventObj.cancelled = true
		Text.showMessageBox("Ahora debes moverte rapido, esas plataformas no se ven nada robustos.")
	elseif string.find(msgStr, "I dropped all my") then
		eventObj.cancelled = true
		Text.showMessageBox("Se me cayeron mis monedas Frog Coins. Si las encontras por mi te doy un premio.")
	elseif string.find(msgStr, "I will give you something special") then
		eventObj.cancelled = true
		Text.showMessageBox("Te voy a dar algo especial si me traes todas las Monedas Rojas.")
	elseif string.find(msgStr, "Those bubbles look pretty") then
		eventObj.cancelled = true
		Text.showMessageBox("Esas burvujas se ven bastantes fuertes. Me pregunto si es posible nadar en ellas?")
	elseif string.find(msgStr, "The Clown Car is weak on") then
		eventObj.cancelled = true
		Text.showMessageBox("El Clown Car (Coche Payaso) es debil en la parte de harriba. Va a doler si un enemigo te toca ahi.")
	elseif string.find(msgStr, "You can stack those cannons") then
		eventObj.cancelled = true
		Text.showMessageBox("Podes apilar esos Billy Guns en cima del Clown Car y dispararlos mientras manejas!")
	elseif string.find(msgStr, "What took you so long?") then
		eventObj.cancelled = true
		if (Player.count() == 1) then Text.showMessageBox("Porque demorastes tanto? Vamonos.")
		else Text.showMessageBox("Porque demoraron tanto? Vamonos.") end
	elseif string.find(msgStr, "You boys better get off") then
		eventObj.cancelled = true
		if (Player.count() == 1) then Text.showMessageBox("Mas te vale salir de mi jardin!")
		else Text.showMessageBox("Mas les vale salir de mi jardin!") end
	elseif string.find(msgStr, "Stay outta my house.") then
		eventObj.cancelled = true
		if (Player.count() == 1) then Text.showMessageBox("No te quiero cerca de mi casa. La puerta esta cerrada. y ni se te ocurra bajar por la chimenea.")
		else Text.showMessageBox("No los quiero cerca de mi casa. La puerta esta cerrada. y ni se les ocurra bajar por la chimenea.") end
	elseif string.find(msgStr, "you broke into my house.") then
		eventObj.cancelled = true
		if (Player.count() == 1) then Text.showMessageBox("No puedo creer que aigas entrado en mi casa. Mejor que no aigas lastimado a Hugo!")
		else Text.showMessageBox("No puedo creer que aigan entrado en mi casa. Mejor que no aigan lastimado a Hugo!") end
	elseif string.find(msgStr, "Take anything you want!") then
		eventObj.cancelled = true
		Text.showMessageBox("Toma todo lo que quieras!")
	elseif string.find(msgStr, "on your journey.") then
		eventObj.cancelled = true
		Text.showMessageBox("Bienvenido! Porfavor toma cualquier cosa que pueda ayudarte en tu viaje.")
	elseif string.find(msgStr, "The pink Yoshi spits out") then
		eventObj.cancelled = true
		Text.showMessageBox("El Yoshi rosado escupe verduras despues de tragarse a sus enemigos. El Yoshi violeta puede dar un pisoton si pulsas abajo.")
	elseif string.find(msgStr, "Welcome to the Star Palace!") then
		eventObj.cancelled = true
		Text.showMessageBox("Bienvenido al Star Palace! Ahi tesoros especiales que podes recoger mientras tengas suficientes estrellas.")
	elseif string.find(msgStr, "We are Lumas. guardians") then
		eventObj.cancelled = true
		Text.showMessageBox("Nosotros somos Lumas, los guardianos del Star Palace.")
	elseif string.find(msgStr, "This is the Star Palace.") then
		eventObj.cancelled = true
		Text.showMessageBox("Esto es el Star Palace.")
	elseif string.find(msgStr, "The girl in the blue dress") then
		eventObj.cancelled = true
		Text.showMessageBox("La chica del vestido azul es Rosalina!")
	elseif string.find(msgStr, "You need ") and string.find(msgStr, " stars to enter.") then
		eventObj.cancelled = true
		num = ""
		for length = 1, string.len(msgStr) do
			focus = string.sub(msgStr, length, length)
			cond = false
			if (string.find(focus, "0")) then cond = true
			elseif (string.find(focus, "1")) then cond = true
			elseif (string.find(focus, "2")) then cond = true
			elseif (string.find(focus, "3")) then cond = true
			elseif (string.find(focus, "4")) then cond = true
			elseif (string.find(focus, "5")) then cond = true
			elseif (string.find(focus, "6")) then cond = true
			elseif (string.find(focus, "7")) then cond = true
			elseif (string.find(focus, "8")) then cond = true
			elseif (string.find(focus, "9")) then cond = true end
			
			if (cond) then num = num .. focus end
		end
		Text.showMessageBox("Necesitas " .. num .. " estrellas para entrar aca.")
	elseif string.find(msgStr, "You need 1 star to enter.") then
		eventObj.cancelled = true
		Text.showMessageBox("Necesitas 1 estrella para entrar aca.")
	end
end